# Asistencia de ChatGPT

https://chat.openai.com/c/68d3371d-4728-8013-80f5-d4412c4236bf

## USER
Bueno, bueno, ChatGPT nos escucha.

## ASSISTANT
¡Claro que sí, Víctor! Estoy aquí para ayudarte en todo lo que necesites. ¿En qué te gustaría profundizar o qué proyecto estás trabajando hoy?

