# Ilustración de perro artístico

https://chat.openai.com/c/68d3a47e-249c-8320-9313-1f7cfc08bf47

## USER
Convierte esta foto en una ilustración de alta calidad, no fotorrealista.
Un perro mayor negro con marcas canela, hocico canoso y ojos ámbar, tumbado
con las patas delanteras extendidas sobre baldosas crema con azul. Mantén su
identidad y mirada cálida (una oreja algo más erguida), pero hazlo obra de arte:
mezcla de caricatura clásica + ilustración editorial + cómic europeo + shōjo setentero,
línea a tinta expresiva, sombreado con lápiz de color, capas de gouache/acuarela,
textura de papel de algodón, granulado fino, ligeras pinceladas visibles.
Fondo interior doméstico sugerido y pictórico (desenfoque suave), viñeta ligera.
Paleta fiel a la foto (negros profundos con reflejos marrón rojizo, azules/cremas del piso),
luces cálidas y contraluz suave. Nada de 3D/CGI. Composición desde ángulo bajo,
acabado elegante y nostálgico que haga decir “¡guau!”.

## Thoughts
Para esta ilustración, haremos un perro mayor, negro con marcas marrones, que muele un poco, con ojos ámbar y una oreja más erguida. Estará en una posición elegante sobre unos azulejos de color crema y azul. El estilo será cálido y nostálgico, con una mezcla de caricatura clásica, ilustración editorial y manga shōjo de los 70.

