# Respuesta con emoji

https://chat.openai.com/c/68d3a9bb-8bbc-8321-8ba8-41c2be2950bd

## USER
Solo responde con un emoji de carita feliz en este turno

## ASSISTANT
😊

