# Diferencias Markdown JSON

https://chat.openai.com/c/68d626f5-e164-8330-a12a-a57104fce2b1

## USER


## ASSISTANT


## USER


## ASSISTANT


## USER


## ASSISTANT


## USER


## ASSISTANT


## USER


## ASSISTANT


## USER


## ASSISTANT


## USER


## ASSISTANT


## USER


## ASSISTANT


